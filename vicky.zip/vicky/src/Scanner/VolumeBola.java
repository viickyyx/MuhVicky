package Scanner;

import java.util.Scanner;
/**
 *
 * @Muh.Vicky
 */
public class VolumeBola {
    public static void main(String[]args){
        Scanner scan = new Scanner(System.in);
        double volume, radius;
        
        System.out.print("masukkan nilai radius=");
        radius = Double.valueOf(scan.nextLine());
        
        volume = 0.4/0.3*3.14*radius*radius*radius;
        System.out.println("Hasil volume bola="+volume);
        
        //radius = jari-jari
    }
}
